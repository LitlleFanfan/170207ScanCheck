﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace BarCodeScan {
    internal class BarCodeHook {
        public delegate void BarCodeDelegate(BarCodes barCode);

        public struct BarCodes {
            public int VirtKey;
            public int ScanCode;
            public string KeyName;
            public uint AscII;
            public char Chr;
            public string BarCode;
            public bool IsValid;
            public DateTime Time;
        }

        private struct EventMsg {
            public int message;
            public int paramL;
            public int paramH;
            public int Time;
            public int hwnd;
        }

        private delegate int HookProc(int nCode, int wParam, IntPtr lParam);

        private BarCodes barCode = default(BarCodes);

        private int hKeyboardHook;

        private List<char> _barcode = new List<char>(100);

        private static HookProc hookproc;

        public event BarCodeDelegate BarCodeEvent;

        [DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
        private static extern int SetWindowsHookEx(int idHook, BarCodeHook.HookProc lpfn, IntPtr hInstance, int threadId);

        [DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
        private static extern bool UnhookWindowsHookEx(int idHook);

        [DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
        private static extern int CallNextHookEx(int idHook, int nCode, int wParam, IntPtr lParam);

        [DllImport("user32")]
        private static extern int GetKeyNameText(int lParam, StringBuilder lpBuffer, int nSize);

        [DllImport("user32")]
        private static extern int GetKeyboardState(byte[] pbKeyState);

        [DllImport("user32")]
        private static extern bool ToAscii(int VirtualKey, int ScanCode, byte[] lpKeyState, ref uint lpChar, int uFlags);

        private int KeyboardHookProc(int nCode, int wParam, IntPtr lParam) {
            if (nCode == 0) {
                var eventMsg = (EventMsg)Marshal.PtrToStructure(lParam, typeof(EventMsg));
                if (wParam == 256) {
                    this.barCode.VirtKey = (eventMsg.message & 255);
                    this.barCode.ScanCode = (eventMsg.paramL & 255);
                    var stringBuilder = new StringBuilder(255);
                    if (GetKeyNameText(this.barCode.ScanCode * 65536, stringBuilder, 255) > 0) {
                        var arg_9D_0 = stringBuilder.ToString();
                        var array = new char[2];
                        array[0] = ' ';
                        this.barCode.KeyName = arg_9D_0.Trim(array);
                    } else {
                        this.barCode.KeyName = "";
                    }
                    var array2 = new byte[256];
                    var num = 0u;
                    GetKeyboardState(array2);
                    if (ToAscii(this.barCode.VirtKey, this.barCode.ScanCode, array2, ref num, 0)) {
                        this.barCode.AscII = num;
                        this.barCode.Chr = Convert.ToChar(num);
                    }
                    if (DateTime.Now.Subtract(this.barCode.Time).TotalMilliseconds > 100.0) {
                        this._barcode.Clear();
                    } else {
                        if ((eventMsg.message & 255) == 13 && this._barcode.Count > 0) {
                            this.barCode.BarCode = new string(this._barcode.ToArray());
                            this.barCode.IsValid = true;
                        }
                        this._barcode.Add(System.Convert.ToChar(eventMsg.message & 255));
                    }
                    this.barCode.Time = DateTime.Now;
                    if (this.BarCodeEvent != null) {
                        this.BarCodeEvent(this.barCode);
                    }
                    this.barCode.IsValid = false;
                }
            }
            return CallNextHookEx(this.hKeyboardHook, nCode, wParam, lParam);
        }

        public bool Start() {
            if (this.hKeyboardHook == 0) {
                hookproc = new HookProc(this.KeyboardHookProc);
                this.hKeyboardHook = SetWindowsHookEx(13, 
                    hookproc, 
                    Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]), 0);
            }
            return this.hKeyboardHook != 0;
        }

        public bool Stop() {
            return this.hKeyboardHook == 0 || BarCodeHook.UnhookWindowsHookEx(this.hKeyboardHook);
        }
    }
}
