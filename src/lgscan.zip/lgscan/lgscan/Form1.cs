﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

using OfficeOpenXml;
using OfficeOpenXml.Style;

using BarCodeScan;

namespace lgscan {
    public partial class Form1 : Form {
        private delegate void ShowInfoDelegate(BarCodeHook.BarCodes barCode);

        private string strCurrentBoxNo = "";

        private string strCurrentBarCode = "";

        private int iTotalNumber;

        private int iRow = 1;

        private ExcelPackage package;

        private string strFilePath;

        private int iLastStatus = -1;

        private BarCodeHook BarCode = new BarCodeHook();

        private bool bShowTxt;

        private bool bBusy;

        private int iCurrentIndex;

        private string sComPort = "";

        public Form1() {
            InitializeComponent();

            Text = "装柜计数系统 v1.0";
            lblResult.Text = ""; // 清除报警信息。

            this.BarCode.BarCodeEvent += new BarCodeHook.BarCodeDelegate(this.BarCode_BarCodeEvent);
            this.bShowTxt = false;
            if (this.bShowTxt) {
                this.timerClick.Enabled = true;
            } else {
                this.txtBarCode.Left = 1000;
            }
            this.txtBarCode.Visible = true;
            this.txtBarCode.Focus();

            addLog("程序启动。");
            WriteFile($"程序启动: {Text}");
        }

        private void btnExit_Click(object sender, EventArgs e) {
            var b = MessageBox.Show("确认要退出软件吗?", "退出确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (b == DialogResult.Yes) {
                Close();
            }
        }

        private void HandleBarCode(BarCodeHook.BarCodes barCode) {
            this.txtBarCode.Focus();
            if (base.InvokeRequired) {
                base.BeginInvoke(new ShowInfoDelegate(this.HandleBarCode), 
                    new object[] { barCode });
                return;
            }
            if (barCode.IsValid) {
                this.txtBarCode.Text = barCode.BarCode.Replace("\r", "");
                this.txtBarCode.Focus();
                var num = this.InputItem();
                this.txtBarCode.Focus();
                if (this.iLastStatus != num) {
                    try {
                        this.iLastStatus = num;
                        if (this.sComPort != "") {
                            if (num == 0) {
                                addLog("打开PLC，端口：" + this.sComPort);
                                WriteFile("打开PLC，端口：" + this.sComPort);
                            } else {
                                addLog("关闭PLC，端口：" + this.sComPort);
                                WriteFile("关闭PLC，端口：" + this.sComPort);
                            }
                            PLC.Open(this.sComPort);
                            PLC.setM("R0", (num == 0) ? 1 : 0);
                            PLC.Close();
                            this.WriteFile(this.lblBarCode.Text + this.iLastStatus.ToString());
                        }
                    } catch (System.Exception ex) {
                        WriteFile("HandleBarCode启动PLC出错！错误为：" + ex.Message);
                    }
                }
                if (num == 0) {
                    lblResult.Text = "";
                    return;
                }
                if (num == 1) {
                    lblResult.Text = "当前商品已经装满，请装其它商品！";
                    return;
                }
                if (num == 2) {
                    lblResult.Text = "当前商品未装满，不允许装其它商品！";
                }
            }
        }

        private void BarCode_BarCodeEvent(BarCodeHook.BarCodes barCode) {
            this.HandleBarCode(barCode);
        }

        public static DataSet ToDataTable(string filePath) {
            var extension = Path.GetExtension(filePath);
            if (string.IsNullOrEmpty(extension)) {
                return null;
            }
            string connectionString;
            if (extension == ".xls") {
                connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" + filePath + "\";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=1\"";
            } else {
                connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"" + filePath + "\";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1\"";
            }
            var format = "Select * FROM [{0}]";
            OleDbConnection oleDbConnection = null;
            OleDbDataAdapter oleDbDataAdapter = null;
            var dataSet = new DataSet();
            try {
                oleDbConnection = new OleDbConnection(connectionString);
                oleDbConnection.Open();
                var oleDbSchemaTable = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[]
                {
                    null,
                    null,
                    null,
                    "TABLE"
                });
                oleDbDataAdapter = new OleDbDataAdapter();
                for (int i = 0; i < oleDbSchemaTable.Rows.Count; i++) {
                    var text = (string)oleDbSchemaTable.Rows[i]["TABLE_NAME"];
                    if (!text.Contains("$") || text.Replace("'", "").EndsWith("$")) {
                        oleDbDataAdapter.SelectCommand = new OleDbCommand(string.Format(format, text), oleDbConnection);
                        var dataSet2 = new DataSet();
                        oleDbDataAdapter.Fill(dataSet2, text);
                        dataSet.Tables.Add(dataSet2.Tables[0].Copy());
                    }
                }
            } catch (Exception ex) {
                if (ex.Message.IndexOf("未在本地计算机上注册") >= 0) {
                    MessageBox.Show(ex.Message);
                } else {
                    MessageBox.Show("请关闭文件后再点击打开！" + ex.Message);
                }
            } finally {
                if (oleDbConnection.State == ConnectionState.Open) {
                    oleDbConnection.Close();
                    oleDbDataAdapter.Dispose();
                    oleDbConnection.Dispose();
                }
            }
            return dataSet;
        }

        private void openExcel() {
            var text = "";
            var num = 0;
            openFile.Filter = "Excel Files|*.xls;*.xlsx";
            if (openFile.ShowDialog() == DialogResult.OK) {
                text = openFile.FileName;
            }
            if (text == "") {
                return;
            }
            strFilePath = text;
            iTotalNumber = 0;
            try {
                var dataSet = ToDataTable(text);
                if (dataSet.Tables.Count != 0) {
                    var dataTable = dataSet.Tables[0];
                    var dataTable2 = new DataTable();
                    if (dataTable != null) {
                        lblBoxNo.Text = dataTable.Rows[2][14].ToString();
                        strCurrentBoxNo = lblBoxNo.Text;
                        dataTable2.Columns.Add("EVNo");
                        dataTable2.Columns.Add("Number", typeof(int));
                        dataTable2.Columns.Add("Already", typeof(int));
                        var fileName = this.GetFileName();
                        if (File.Exists(fileName)) {
                            if (MessageBox.Show("当前柜已有装柜记录，是否继续之前的装柜？", "重要提示", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes) {
                                var dataSet2 = ToDataTable(fileName);
                                if (dataSet2.Tables.Count == 0) {
                                    MessageBox.Show("此文件数据已经被修改，无法正确加载！请删除\r\n" + fileName + " 后再打开！", "重要提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                                var dataTable3 = dataSet2.Tables[this.lblBoxNo.Text + "$"];
                                var num2 = 0;
                                var num3 = 0;
                                var text2 = "";
                                for (int i = 0; i < dataTable3.Rows.Count; i++) {
                                    var dataRow = dataTable3.Rows[i];
                                    if (dataRow[0].ToString() == "") {
                                        break;
                                    }
                                    var num4 = int.Parse(dataRow[1].ToString());
                                    var num5 = int.Parse(dataRow[2].ToString());
                                    var dataRow2 = dataTable2.NewRow();
                                    dataRow2["EVNo"] = dataRow[0].ToString();
                                    dataRow2["Number"] = num4;
                                    dataRow2["Already"] = num5;
                                    if (num4 > num5 & num5 > 0 & num3 == 0) {
                                        num2 = num4;
                                        num3 = num5;
                                        text2 = dataRow[0].ToString();
                                        this.iCurrentIndex = i;
                                    }
                                    num += int.Parse(dataRow[2].ToString());
                                    dataTable2.Rows.Add(dataRow2);
                                }
                                this.lblBarCode.Text = text2;
                                this.lblCurrentNeedNumber.Text = num2.ToString();
                                this.lblCurrentNumber.Text = num3.ToString();
                                this.lblAlreadyNumber.Text = num.ToString();
                            } else {
                                System.IO.File.Delete(fileName);
                                this.lblBarCode.Text = "";
                                this.lblCurrentNeedNumber.Text = "0";
                                this.lblCurrentNumber.Text = "0";
                                this.lblAlreadyNumber.Text = "0";
                                for (int j = 6; j < dataTable.Rows.Count; j++) {
                                    var dataRow = dataTable.Rows[j];
                                    if (dataRow[0].ToString() == "") {
                                        break;
                                    }
                                    var dataRow2 = dataTable2.NewRow();
                                    dataRow2["EVNo"] = dataRow[2].ToString();
                                    dataRow2["Number"] = int.Parse(dataRow[7].ToString());
                                    dataRow2["Already"] = 0;
                                    dataTable2.Rows.Add(dataRow2);
                                }
                            }
                        } else {
                            for (int k = 6; k < dataTable.Rows.Count; k++) {
                                var dataRow = dataTable.Rows[k];
                                if (dataRow[2].ToString() == "") {
                                    break;
                                }
                                var dataRow2 = dataTable2.NewRow();
                                dataRow2["EVNo"] = dataRow[2].ToString();
                                dataRow2["Number"] = int.Parse(dataRow[7].ToString());
                                dataRow2["Already"] = 0;
                                dataTable2.Rows.Add(dataRow2);
                            }
                        }
                        this.gvData.DataSource = dataTable2;
                        this.gvData.Columns[0].HeaderCell.Value = "EV号码";
                        this.gvData.Columns[1].HeaderCell.Value = "箱数";
                        this.gvData.Columns[2].HeaderCell.Value = "已装箱数";
                        this.gvData.Columns[0].Width = 132;
                        this.gvData.Columns[1].Width = 100;
                        this.gvData.Columns[2].Width = 100;
                        this.gvData.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
                        this.gvData.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomRight;
                        if (this.gvData.Rows.Count > 0 & num > 0) {
                            this.gvData.Rows[this.iCurrentIndex].Selected = true;
                        }
                        
                        //gvData.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                        //gvData.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                        //gvData.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;                        

                        this.lblResult.Text = "";
                        try {
                            if (this.sComPort != "") {
                                this.WriteFile("启动PLC，端口：" + this.sComPort);
                                PLC.Open(this.sComPort);
                                PLC.setM("R0", 1);
                                PLC.Close();
                            }
                        } catch (Exception ex) {
                            this.WriteFile("打开Excel文件后启动PLC出错！" + ex.Message);
                        }

                        if (this.bShowTxt) {
                            this.txtBarCode.Focus();
                        }

                        addLog("加载Excel完毕。");
                    }
                }
            } catch (Exception ex2) {
                this.WriteFile("加载Excel数据出错，请检查Excel格式是否正确！" + ex2.Message);
                MessageBox.Show("加载Excel数据出错，请检查Excel格式是否正确！", "错误提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void gvData_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e) {
            if (e.RowIndex == this.gvData.Rows.Count - 1) {
                return;
            }
            var bounds = new Rectangle(e.RowBounds.Location.X, e.RowBounds.Location.Y, this.gvData.RowHeadersWidth - 4, e.RowBounds.Height);
            TextRenderer.DrawText(e.Graphics, (e.RowIndex + 1).ToString(), this.gvData.RowHeadersDefaultCellStyle.Font, bounds, this.gvData.RowHeadersDefaultCellStyle.ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        private void timerClick_Tick(object sender, EventArgs e) {
            int num = this.InputItem();
            if (num == 0) {
                this.lblResult.Text = "";
                return;
            }
            if (num == 1) {
                this.lblResult.Text = "当前商品已经装满，请装其它商品！";
                return;
            }
            if (num == 2) {
                this.lblResult.Text = "当前商品未装满，不允许装其它商品！";
            }
        }

        public int InputItem() {
            int result = -1;
            try {
                if (this.txtBarCode.Text.Trim() == "" || this.txtBarCode.Text.Trim().Length < 10) {
                    return result;
                }
                if (this.txtBarCode.Text.Trim() != "" & this.strCurrentBarCode != this.txtBarCode.Text) {
                    this.strCurrentBarCode = this.txtBarCode.Text.Replace("\r\n", "");
                }
                for (int i = 0; i < this.gvData.Rows.Count - 1; i++) {
                    string a = this.gvData.Rows[i].Cells[0].Value.ToString();
                    int num = int.Parse(this.gvData.Rows[this.iCurrentIndex].Cells[1].Value.ToString());
                    int num2 = int.Parse(this.gvData.Rows[this.iCurrentIndex].Cells[2].Value.ToString());
                    if (this.lblBarCode.Text != this.strCurrentBarCode & num > num2 & num2 > 0) {
                        result = 2;
                        break;
                    }
                    this.gvData.Rows[i].Selected = false;
                    int num3;
                    int num4;
                    if (a == this.strCurrentBarCode) {
                        num3 = int.Parse(this.gvData.Rows[i].Cells[1].Value.ToString());
                        num4 = int.Parse(this.gvData.Rows[i].Cells[2].Value.ToString());
                        this.lblCurrentNeedNumber.Text = num3.ToString();
                        this.lblBarCode.Text = this.strCurrentBarCode;
                        if (num3 > num4) {
                            this.gvData.Rows[i].Cells[2].Value = int.Parse(this.gvData.Rows[i].Cells[2].Value.ToString()) + 1;
                            this.lblCurrentNumber.Text = this.gvData.Rows[i].Cells[2].Value.ToString();
                            result = 0;
                            this.iRow++;
                            this.SaveAlreadyInfo();
                            this.SaveAlreadyItemTimeInfo(this.lblBarCode.Text);
                        } else {
                            this.lblCurrentNumber.Text = num4.ToString();
                            result = 1;
                        }
                        this.iCurrentIndex = i;
                        this.gvData.Rows[i].Selected = true;
                        break;
                    }
                    num3 = int.Parse(this.gvData.Rows[this.iCurrentIndex].Cells[1].Value.ToString());
                    num4 = int.Parse(this.gvData.Rows[this.iCurrentIndex].Cells[2].Value.ToString());
                    if (this.strCurrentBarCode != this.gvData.Rows[this.iCurrentIndex].Cells[0].Value.ToString()) {
                        if (num3 > num4 & num4 > 0) {
                            if (this.strCurrentBarCode == this.gvData.Rows[i].Cells[0].Value.ToString()) {
                                this.gvData.Rows[i].Selected = true;
                            }
                            result = 2;
                            break;
                        }
                        if (num4 == 0) {
                            this.iRow = 0;
                        }
                    }
                }
                this.iTotalNumber = 0;
                for (int j = 0; j < this.gvData.Rows.Count - 1; j++) {
                    this.iTotalNumber += int.Parse(this.gvData.Rows[j].Cells[2].Value.ToString());
                }
                this.lblAlreadyNumber.Text = this.iTotalNumber.ToString();
            } catch (System.Exception ex) {
                this.WriteFile("装柜，并返回装柜状态出错！错误为：" + ex.Message);
            }
            this.txtBarCode.Text = "";
            this.txtBarCode.Focus();
            return result;
        }

        private void CreateAlreadyExcel() {
            try {
                var fileName = this.GetFileName();
                if (!File.Exists(fileName)) {
                    var newFile = new FileInfo(fileName);
                    this.package = new ExcelPackage(newFile);
                    using (ExcelPackage excelPackage = new ExcelPackage(newFile)) {
                        excelPackage.Workbook.Worksheets[0].Select();
                        var excelWorksheet = excelPackage.Workbook.Worksheets[this.lblBoxNo.Text];
                        if (excelWorksheet == null) {
                            excelWorksheet = excelPackage.Workbook.Worksheets.Add(this.lblBoxNo.Text);
                        }
                        excelWorksheet.Cells.Style.ShrinkToFit = true;
                        excelPackage.Save();
                    }
                }
            } catch (Exception ex) {
                this.WriteFile("创建Excel文件出错！错误为：" + ex.Message);
                MessageBox.Show("请关闭文件后再点击打开！", "错误提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }

        private void SaveAlreadyInfo() {
            var fileName = this.GetFileName();
            Path.GetFileName(fileName);
            try {
                if (this.bBusy) {
                    this.WriteFile("SaveAlreadyInfo() is busy !");
                } else {
                    this.bBusy = true;
                    var newFile = new FileInfo(fileName);
                    using (ExcelPackage excelPackage = new ExcelPackage(newFile)) {
                        var excelWorksheet = excelPackage.Workbook.Worksheets[this.lblBoxNo.Text];
                        if (excelWorksheet != null) {
                            excelPackage.Workbook.Worksheets.Delete(this.lblBoxNo.Text);
                        }
                        excelWorksheet = excelPackage.Workbook.Worksheets.Add(this.lblBoxNo.Text);
                        excelWorksheet.Cells["A1"].Value = "EV号码";
                        excelWorksheet.Cells["B1"].Value = "箱数";
                        excelWorksheet.Cells["C1"].Value = "已装箱数";
                        excelWorksheet.Column(2).Style.Numberformat.Format = "#,##0";
                        excelWorksheet.Column(3).Style.Numberformat.Format = "#,##0";
                        for (int i = 0; i < this.gvData.Rows.Count - 1; i++) {
                            excelWorksheet.Cells["A" + (i + 2)].Value = this.gvData.Rows[i].Cells[0].Value;
                            excelWorksheet.Cells["B" + (i + 2)].Value = this.gvData.Rows[i].Cells[1].Value;
                            excelWorksheet.Cells["C" + (i + 2)].Value = this.gvData.Rows[i].Cells[2].Value;
                            excelWorksheet.Column(1).Width = 14.0;
                            excelWorksheet.Column(2).Width = 8.0;
                            excelWorksheet.Column(3).Width = 12.0;
                        }
                        excelPackage.Save();
                    }
                    this.bBusy = false;
                }
            } catch (Exception ex) {
                this.WriteFile("保存已装箱商品信息！错误为：" + ex.Message);
            }
        }

        private void SaveAlreadyItemTimeInfo(string sheetName) {
            var fileName = this.GetFileName();
            Path.GetFileName(fileName);
            try {
                if (this.bBusy) {
                    this.WriteFile("SaveAlreadyItemTimeInfo() is busy !");
                } else {
                    this.bBusy = true;
                    var newFile = new FileInfo(fileName);
                    using (ExcelPackage excelPackage = new ExcelPackage(newFile)) {
                        var excelWorksheet = excelPackage.Workbook.Worksheets[sheetName];
                        if (excelWorksheet == null) {
                            excelWorksheet = excelPackage.Workbook.Worksheets.Add(sheetName);
                        }
                        excelWorksheet.Cells["A1"].Value = "装柜时间";
                        excelWorksheet.Column(1).Width = 22.0;
                        excelWorksheet.Column(1).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss fff";
                        excelWorksheet.Column(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        var end = excelWorksheet.Dimension.End;
                        excelWorksheet.Cells["A" + (end.Row + 1)].Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss fff");
                        excelPackage.Save();
                    }
                    this.bBusy = false;
                }
            } catch (Exception ex) {
                this.WriteFile("保存已装箱商品时间信息出错！错误为：" + ex.Message);
            }
        }

        private string GetFileName() {
            Path.GetExtension(this.strFilePath);
            return this.strFilePath.Substring(0, this.strFilePath.LastIndexOf("\\")) + "\\" + this.lblBoxNo.Text + "柜装箱记录表.xlsx";
        }

        private void frmMain_Load(object sender, EventArgs e) {
            var portNames = SerialPort.GetPortNames();
            for (int i = 0; i < portNames.Length; i++) {
                if (portNames[i].ToUpper() == "COM3" || portNames[i].ToUpper() == "COM4") {
                    this.sComPort = portNames[i];
                    break;
                }
            }
            this.BarCode.Start();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e) {
            this.BarCode.Stop();
        }

        public void WriteFile(string sData) {
            try {
                var path = string.Concat(new string[] {
                    Application.StartupPath,
                    this.lblBoxNo.Text,
                    "_",
                    DateTime.Now.ToString("yyyyMMdd"),
                    ".log"
                });
                if (this.lblBoxNo.Text == "") {
                    path = "C:\\PLC_" + DateTime.Now.ToString("yyyyMMdd") + ".log";
                }
                //var d = DateTime.Now.ToString("yyyyMMdd");
                //var path = $"{Application.StartupPath}_{d}.log";

                var fileStream = new FileStream(path, FileMode.Append);
                var encoding = Encoding.GetEncoding("gb2312");
                var streamWriter = new StreamWriter(fileStream, encoding);
                streamWriter.Write(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss fff") + "\t\t" + sData + "\r\n");
                streamWriter.Flush();
                streamWriter.Close();
                fileStream.Close();                
            } catch (Exception ex) {
                MessageBox.Show("写日志文件出现了错：" + ex.Message);
            }
        }

        private void btnOpenExcel_Click(object sender, EventArgs e) {
            openExcel();            
        }

        private void addLog(string msg) {
            var count = lbxLog.Items.Count;
            if (count > 1000) {
                lbxLog.Items.RemoveAt(count - 1);
            }
            
            var s = $"[{DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")}] {msg}";
            lbxLog.Items.Insert(0, s);
        }
    }
}
